export const colors = {
  background: '#0A0A0F',
  surface: '#12121A',
  surfaceElevated: '#1A1A26',
  border: '#2A2A3E',
  borderLight: '#3A3A55',

  primary: '#9333EA',
  primaryLight: '#A855F7',
  primaryDark: '#7C3AED',
  primaryGlow: 'rgba(147, 51, 234, 0.3)',

  accent: '#C084FC',
  accentLight: '#E9D5FF',

  text: '#F5F3FF',
  textSecondary: '#A78BFA',
  textMuted: '#6B6B8A',

  success: '#22C55E',
  warning: '#F59E0B',
  error: '#EF4444',

  gradient: {
    primary: ['#7C3AED', '#9333EA'],
    dark: ['#0A0A0F', '#12121A'],
    card: ['#1A1A26', '#12121A'],
    glow: ['rgba(147, 51, 234, 0.2)', 'transparent'],
  },
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 9999,
};

export const typography = {
  h1: { fontSize: 32, fontWeight: '700' as const, letterSpacing: -0.5 },
  h2: { fontSize: 24, fontWeight: '700' as const, letterSpacing: -0.3 },
  h3: { fontSize: 20, fontWeight: '600' as const },
  body: { fontSize: 16, fontWeight: '400' as const, lineHeight: 24 },
  bodySmall: { fontSize: 14, fontWeight: '400' as const, lineHeight: 20 },
  caption: { fontSize: 12, fontWeight: '400' as const },
  label: { fontSize: 13, fontWeight: '600' as const, letterSpacing: 0.5 },
};
