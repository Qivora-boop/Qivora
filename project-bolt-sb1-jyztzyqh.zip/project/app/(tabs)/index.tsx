import { useState, useRef } from 'react';
import {
  View, Text, TextInput, StyleSheet, ScrollView,
  TouchableOpacity, Animated, Image, ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Sparkles, Wand2, ChevronRight, Zap } from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { getSimulatedImage, IMAGE_STYLES } from '@/lib/imageGenerator';
import GradientButton from '@/components/GradientButton';
import { colors, spacing, radius, typography } from '@/constants/theme';

const EXAMPLE_PROMPTS = [
  'A cyberpunk city at night with neon lights',
  'A dragon soaring through a mystical forest',
  'Portrait of an astronaut on Mars',
  'Serene Japanese garden in autumn',
];

export default function HomeScreen() {
  const { user, profile, refreshProfile } = useAuth();
  const [prompt, setPrompt] = useState('');
  const [selectedStyle, setSelectedStyle] = useState('realistic');
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  function startPulse() {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.08, duration: 800, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      ])
    ).start();
    Animated.timing(fadeAnim, { toValue: 1, duration: 300, useNativeDriver: true }).start();
  }

  function stopPulse() {
    pulseAnim.stopAnimation();
    pulseAnim.setValue(1);
    Animated.timing(fadeAnim, { toValue: 0, duration: 300, useNativeDriver: true }).start();
  }

  async function handleGenerate() {
    if (!prompt.trim()) {
      setError('Please enter a prompt');
      return;
    }
    if (!profile || profile.credits < 1) {
      setError('Not enough credits. Buy more to continue!');
      return;
    }
    setError(null);
    setGenerating(true);
    startPulse();

    try {
      // Simulate generation delay
      await new Promise(r => setTimeout(r, 2500));

      const imageUrl = getSimulatedImage(selectedStyle, prompt.trim());

      // Deduct credit and save image
      const { data: imageData } = await supabase.from('generated_images').insert({
        user_id: user!.id,
        prompt: prompt.trim(),
        style: selectedStyle,
        image_url: imageUrl,
        is_saved: false,
      }).select('id').single();

      await Promise.all([
        supabase.from('profiles').update({ credits: profile.credits - 1, updated_at: new Date().toISOString() })
          .eq('id', user!.id),
        supabase.from('credit_transactions').insert({
          user_id: user!.id,
          amount: -1,
          type: 'generation',
          description: `Generated: ${prompt.trim().slice(0, 50)}`,
        }),
      ]);

      await refreshProfile();

      if (imageData) {
        router.push({ pathname: '/(tabs)/result', params: { imageId: (imageData as { id: string }).id } });
      }
    } catch {
      setError('Generation failed. Please try again.');
    } finally {
      setGenerating(false);
      stopPulse();
    }
  }

  return (
    <LinearGradient colors={[colors.background, '#0A0A1A']} style={styles.bg}>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.topBar}>
          <View>
            <Text style={styles.greeting}>Hello, {profile?.username ?? 'Creator'} 👋</Text>
            <Text style={styles.subtitle}>What will you create today?</Text>
          </View>
          <TouchableOpacity
            style={styles.creditsBadge}
            onPress={() => router.push('/(tabs)/credits')}
          >
            <Zap color={colors.warning} size={14} fill={colors.warning} />
            <Text style={styles.creditsText}>{profile?.credits ?? 0}</Text>
          </TouchableOpacity>
        </View>

        {/* Featured banner */}
        <LinearGradient
          colors={['rgba(124, 58, 237, 0.3)', 'rgba(147, 51, 234, 0.1)']}
          style={styles.banner}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          <View style={styles.bannerContent}>
            <Wand2 color={colors.primaryLight} size={28} />
            <View style={{ flex: 1 }}>
              <Text style={styles.bannerTitle}>AI Image Generator</Text>
              <Text style={styles.bannerDesc}>Describe anything — we'll make it real</Text>
            </View>
          </View>
        </LinearGradient>

        {/* Prompt input */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Your Prompt</Text>
          <View style={styles.promptContainer}>
            <TextInput
              style={styles.promptInput}
              placeholder="Describe the image you want to create..."
              placeholderTextColor={colors.textMuted}
              value={prompt}
              onChangeText={setPrompt}
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />
            <View style={styles.charCount}>
              <Text style={styles.charCountText}>{prompt.length}/500</Text>
            </View>
          </View>

          {/* Example prompts */}
          <Text style={styles.examplesLabel}>Try an example:</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.examples}>
            {EXAMPLE_PROMPTS.map((p, i) => (
              <TouchableOpacity
                key={i}
                style={styles.exampleChip}
                onPress={() => setPrompt(p)}
              >
                <Text style={styles.exampleText}>{p}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Style selector */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Art Style</Text>
          <View style={styles.stylesGrid}>
            {IMAGE_STYLES.map((style) => (
              <TouchableOpacity
                key={style.id}
                style={[styles.styleCard, selectedStyle === style.id && styles.styleCardActive]}
                onPress={() => setSelectedStyle(style.id)}
                activeOpacity={0.75}
              >
                {selectedStyle === style.id && (
                  <LinearGradient
                    colors={[colors.primaryDark, colors.primary]}
                    style={[StyleSheet.absoluteFillObject, { borderRadius: radius.md }]}
                  />
                )}
                <Text style={styles.styleIcon}>{style.icon}</Text>
                <Text style={[styles.styleLabel, selectedStyle === style.id && styles.styleLabelActive]}>
                  {style.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Error */}
        {error && (
          <View style={styles.errorBox}>
            <Text style={styles.errorText}>{error}</Text>
            {error.includes('credits') && (
              <TouchableOpacity onPress={() => router.push('/(tabs)/credits')}>
                <Text style={styles.errorLink}>Get Credits <ChevronRight size={12} color={colors.primaryLight} /></Text>
              </TouchableOpacity>
            )}
          </View>
        )}

        {/* Generate button */}
        <Animated.View style={{ transform: [{ scale: generating ? pulseAnim : 1 }] }}>
          <GradientButton
            title={generating ? 'Generating...' : 'Generate Image'}
            onPress={handleGenerate}
            loading={generating}
            style={styles.generateBtn}
          />
        </Animated.View>

        {generating && (
          <Animated.View style={[styles.loadingOverlay, { opacity: fadeAnim }]}>
            <View style={styles.loadingCard}>
              <View style={styles.loadingDots}>
                {[0, 1, 2].map(i => (
                  <LoadingDot key={i} delay={i * 200} />
                ))}
              </View>
              <Text style={styles.loadingText}>AI is painting your vision...</Text>
              <Text style={styles.loadingSubtext}>This takes a few seconds</Text>
            </View>
          </Animated.View>
        )}

        {/* Recent prompt info */}
        <View style={styles.tipBox}>
          <Sparkles color={colors.primaryLight} size={14} />
          <Text style={styles.tipText}>
            More detailed prompts create better results. Try including colors, mood, and setting.
          </Text>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

function LoadingDot({ delay }: { delay: number }) {
  const anim = useRef(new Animated.Value(0)).current;
  useState(() => {
    Animated.loop(
      Animated.sequence([
        Animated.delay(delay),
        Animated.timing(anim, { toValue: -8, duration: 400, useNativeDriver: true }),
        Animated.timing(anim, { toValue: 0, duration: 400, useNativeDriver: true }),
        Animated.delay(400),
      ])
    ).start();
  });
  return (
    <Animated.View style={[styles.dot, { transform: [{ translateY: anim }] }]} />
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1 },
  scroll: { padding: spacing.lg, paddingTop: 60, paddingBottom: 100 },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: spacing.lg,
  },
  greeting: { ...typography.h2, color: colors.text },
  subtitle: { ...typography.bodySmall, color: colors.textMuted, marginTop: 2 },
  creditsBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(245, 158, 11, 0.12)',
    borderRadius: radius.full,
    paddingVertical: 7,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderColor: 'rgba(245, 158, 11, 0.3)',
  },
  creditsText: { color: colors.warning, fontWeight: '700', fontSize: 14 },
  banner: {
    borderRadius: radius.xl,
    padding: spacing.md,
    marginBottom: spacing.lg,
    borderWidth: 1,
    borderColor: 'rgba(147, 51, 234, 0.2)',
  },
  bannerContent: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  bannerTitle: { ...typography.h3, color: colors.text },
  bannerDesc: { ...typography.bodySmall, color: colors.textSecondary, marginTop: 2 },
  section: { marginBottom: spacing.lg },
  sectionLabel: { ...typography.label, color: colors.textSecondary, textTransform: 'uppercase', marginBottom: spacing.sm },
  promptContainer: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: 'hidden',
  },
  promptInput: {
    color: colors.text,
    padding: spacing.md,
    ...typography.body,
    minHeight: 120,
  },
  charCount: { alignItems: 'flex-end', padding: spacing.sm },
  charCountText: { ...typography.caption, color: colors.textMuted },
  examplesLabel: { ...typography.caption, color: colors.textMuted, marginTop: spacing.sm, marginBottom: spacing.xs },
  examples: { marginHorizontal: -spacing.lg, paddingHorizontal: spacing.lg },
  exampleChip: {
    backgroundColor: colors.surfaceElevated,
    borderRadius: radius.full,
    borderWidth: 1,
    borderColor: colors.border,
    paddingVertical: 7,
    paddingHorizontal: 14,
    marginRight: spacing.sm,
    maxWidth: 220,
  },
  exampleText: { ...typography.caption, color: colors.textSecondary },
  stylesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.sm,
  },
  styleCard: {
    width: '22%',
    aspectRatio: 1,
    backgroundColor: colors.surface,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    gap: 4,
  },
  styleCardActive: {
    borderColor: colors.primary,
  },
  styleIcon: { fontSize: 20 },
  styleLabel: { fontSize: 10, color: colors.textMuted, fontWeight: '600', textAlign: 'center' },
  styleLabelActive: { color: '#fff' },
  errorBox: {
    backgroundColor: 'rgba(239,68,68,0.1)',
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
    padding: spacing.md,
    marginBottom: spacing.md,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  errorText: { color: colors.error, ...typography.bodySmall, flex: 1 },
  errorLink: { color: colors.primaryLight, ...typography.bodySmall, fontWeight: '600' },
  generateBtn: { marginBottom: spacing.md },
  loadingOverlay: { marginBottom: spacing.lg },
  loadingCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.xl,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.lg,
    alignItems: 'center',
  },
  loadingDots: { flexDirection: 'row', gap: 8, marginBottom: spacing.md },
  dot: { width: 10, height: 10, borderRadius: 5, backgroundColor: colors.primary },
  loadingText: { ...typography.body, color: colors.text, fontWeight: '600', marginBottom: 4 },
  loadingSubtext: { ...typography.caption, color: colors.textMuted },
  tipBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: spacing.sm,
    backgroundColor: 'rgba(147, 51, 234, 0.08)',
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: 'rgba(147, 51, 234, 0.15)',
    padding: spacing.md,
  },
  tipText: { ...typography.caption, color: colors.textSecondary, flex: 1, lineHeight: 18 },
});
