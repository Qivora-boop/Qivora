import { useEffect, useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, Image, TouchableOpacity,
  Modal, Pressable, ScrollView, RefreshControl, ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect } from 'expo-router';
import { Bookmark, Trash2, X, Download, Share2, Search } from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { IMAGE_STYLES } from '@/lib/imageGenerator';
import { colors, spacing, radius, typography } from '@/constants/theme';

type GeneratedImage = {
  id: string;
  prompt: string;
  style: string;
  image_url: string;
  is_saved: boolean;
  created_at: string;
};

export default function GalleryScreen() {
  const { user } = useAuth();
  const [images, setImages] = useState<GeneratedImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState<'all' | 'saved'>('all');
  const [selectedImage, setSelectedImage] = useState<GeneratedImage | null>(null);

  useFocusEffect(useCallback(() => { loadImages(); }, []));

  async function loadImages() {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from('generated_images')
      .select('id, user_id, prompt, style, image_url, is_saved, created_at')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    setImages((data as GeneratedImage[]) ?? []);
    setLoading(false);
  }

  async function onRefresh() {
    setRefreshing(true);
    await loadImages();
    setRefreshing(false);
  }

  async function toggleSave(image: GeneratedImage) {
    const newSaved = !image.is_saved;
    await supabase.from('generated_images').update({ is_saved: newSaved }).eq('id', image.id);
    setImages(prev => prev.map(i => i.id === image.id ? { ...i, is_saved: newSaved } : i));
    if (selectedImage?.id === image.id) setSelectedImage(prev => prev ? { ...prev, is_saved: newSaved } : null);
  }

  async function deleteImage(image: GeneratedImage) {
    await supabase.from('generated_images').delete().eq('id', image.id);
    setImages(prev => prev.filter(i => i.id !== image.id));
    setSelectedImage(null);
  }

  const displayed = filter === 'saved' ? images.filter(i => i.is_saved) : images;

  const renderItem = ({ item }: { item: GeneratedImage }) => {
    const styleInfo = IMAGE_STYLES.find(s => s.id === item.style);
    return (
      <TouchableOpacity style={styles.gridItem} onPress={() => setSelectedImage(item)} activeOpacity={0.8}>
        <Image source={{ uri: item.image_url }} style={styles.gridImage} resizeMode="cover" />
        <LinearGradient colors={['transparent', 'rgba(0,0,0,0.85)']} style={styles.gridOverlay}>
          <View style={styles.gridInfo}>
            <Text style={styles.gridStyle}>{styleInfo?.icon} {styleInfo?.label}</Text>
            {item.is_saved && (
              <Bookmark color={colors.primaryLight} size={14} fill={colors.primaryLight} />
            )}
          </View>
        </LinearGradient>
      </TouchableOpacity>
    );
  };

  return (
    <LinearGradient colors={[colors.background, '#0A0A1A']} style={styles.bg}>
      <View style={styles.header}>
        <Text style={styles.title}>Gallery</Text>
        <Text style={styles.subtitle}>{images.length} creations</Text>
      </View>

      {/* Filter tabs */}
      <View style={styles.filterRow}>
        {(['all', 'saved'] as const).map(tab => (
          <TouchableOpacity
            key={tab}
            style={[styles.filterTab, filter === tab && styles.filterTabActive]}
            onPress={() => setFilter(tab)}
          >
            {filter === tab && (
              <LinearGradient
                colors={[colors.primaryDark, colors.primary]}
                style={[StyleSheet.absoluteFillObject, { borderRadius: radius.full }]}
              />
            )}
            <Text style={[styles.filterText, filter === tab && styles.filterTextActive]}>
              {tab === 'all' ? 'All Images' : 'Saved'}
              {tab === 'saved' && ` (${images.filter(i => i.is_saved).length})`}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator color={colors.primary} size="large" />
        </View>
      ) : displayed.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyIcon}>🎨</Text>
          <Text style={styles.emptyTitle}>
            {filter === 'saved' ? 'No saved images yet' : 'No images yet'}
          </Text>
          <Text style={styles.emptyText}>
            {filter === 'saved'
              ? 'Bookmark images from the result screen to save them here'
              : 'Go to the Home tab and generate your first AI image!'}
          </Text>
        </View>
      ) : (
        <FlatList
          data={displayed}
          keyExtractor={i => i.id}
          numColumns={2}
          columnWrapperStyle={styles.row}
          contentContainerStyle={styles.grid}
          renderItem={renderItem}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.primary} />
          }
        />
      )}

      {/* Image detail modal */}
      <Modal visible={!!selectedImage} transparent animationType="fade" onRequestClose={() => setSelectedImage(null)}>
        <Pressable style={styles.modalBg} onPress={() => setSelectedImage(null)}>
          <Pressable style={styles.modalCard} onPress={e => e.stopPropagation()}>
            <LinearGradient colors={[colors.surface, colors.surfaceElevated]} style={[StyleSheet.absoluteFillObject, { borderRadius: radius.xl }]} />
            <TouchableOpacity style={styles.closeBtn} onPress={() => setSelectedImage(null)}>
              <X color={colors.text} size={20} />
            </TouchableOpacity>

            {selectedImage && (
              <>
                <Image source={{ uri: selectedImage.image_url }} style={styles.modalImage} resizeMode="cover" />
                <View style={styles.modalContent}>
                  <View style={styles.modalStyleBadge}>
                    <Text style={styles.modalStyleText}>
                      {IMAGE_STYLES.find(s => s.id === selectedImage.style)?.icon}{' '}
                      {IMAGE_STYLES.find(s => s.id === selectedImage.style)?.label}
                    </Text>
                  </View>
                  <Text style={styles.modalPrompt} numberOfLines={3}>"{selectedImage.prompt}"</Text>
                  <Text style={styles.modalDate}>
                    {new Date(selectedImage.created_at).toLocaleDateString('en-US', {
                      month: 'short', day: 'numeric', year: 'numeric',
                    })}
                  </Text>
                  <View style={styles.modalActions}>
                    <TouchableOpacity
                      style={[styles.modalAction, selectedImage.is_saved && styles.modalActionActive]}
                      onPress={() => toggleSave(selectedImage)}
                    >
                      <Bookmark
                        color={selectedImage.is_saved ? '#fff' : colors.textSecondary}
                        size={18}
                        fill={selectedImage.is_saved ? '#fff' : 'none'}
                      />
                      <Text style={[styles.modalActionText, selectedImage.is_saved && { color: '#fff' }]}>
                        {selectedImage.is_saved ? 'Saved' : 'Save'}
                      </Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[styles.modalAction, styles.modalActionDelete]}
                      onPress={() => deleteImage(selectedImage)}
                    >
                      <Trash2 color={colors.error} size={18} />
                      <Text style={[styles.modalActionText, { color: colors.error }]}>Delete</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </>
            )}
          </Pressable>
        </Pressable>
      </Modal>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1 },
  header: { padding: spacing.lg, paddingTop: 60, paddingBottom: spacing.sm },
  title: { ...typography.h2, color: colors.text },
  subtitle: { ...typography.bodySmall, color: colors.textMuted, marginTop: 2 },
  filterRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.md,
  },
  filterTab: {
    paddingVertical: 9,
    paddingHorizontal: spacing.md,
    borderRadius: radius.full,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: 'hidden',
  },
  filterTabActive: { borderColor: colors.primary },
  filterText: { ...typography.bodySmall, color: colors.textMuted, fontWeight: '600' },
  filterTextActive: { color: '#fff' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xl },
  emptyIcon: { fontSize: 56, marginBottom: spacing.md },
  emptyTitle: { ...typography.h3, color: colors.text, marginBottom: spacing.sm, textAlign: 'center' },
  emptyText: { ...typography.bodySmall, color: colors.textMuted, textAlign: 'center', lineHeight: 20 },
  grid: { paddingHorizontal: spacing.md, paddingBottom: 100 },
  row: { gap: spacing.sm, marginBottom: spacing.sm },
  gridItem: { flex: 1, borderRadius: radius.lg, overflow: 'hidden', aspectRatio: 1 },
  gridImage: { width: '100%', height: '100%' },
  gridOverlay: {
    position: 'absolute',
    bottom: 0, left: 0, right: 0,
    padding: spacing.sm,
    paddingTop: spacing.lg,
  },
  gridInfo: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  gridStyle: { fontSize: 11, color: '#fff', fontWeight: '600' },
  modalBg: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.85)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
  },
  modalCard: {
    width: '100%',
    maxWidth: 400,
    borderRadius: radius.xl,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.border,
  },
  closeBtn: {
    position: 'absolute', top: spacing.md, right: spacing.md,
    zIndex: 10,
    backgroundColor: 'rgba(10,10,15,0.7)',
    borderRadius: radius.full,
    padding: 8,
  },
  modalImage: { width: '100%', aspectRatio: 1 },
  modalContent: { padding: spacing.md },
  modalStyleBadge: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(147,51,234,0.15)',
    borderRadius: radius.full,
    borderWidth: 1,
    borderColor: 'rgba(147,51,234,0.3)',
    paddingVertical: 4,
    paddingHorizontal: 10,
    marginBottom: spacing.sm,
  },
  modalStyleText: { ...typography.caption, color: colors.primaryLight, fontWeight: '600' },
  modalPrompt: { ...typography.bodySmall, color: colors.text, fontStyle: 'italic', marginBottom: 6 },
  modalDate: { ...typography.caption, color: colors.textMuted, marginBottom: spacing.md },
  modalActions: { flexDirection: 'row', gap: spacing.sm },
  modalAction: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: colors.surfaceElevated,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    paddingVertical: 10,
  },
  modalActionActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  modalActionDelete: { borderColor: 'rgba(239,68,68,0.3)', backgroundColor: 'rgba(239,68,68,0.08)' },
  modalActionText: { ...typography.caption, color: colors.textSecondary, fontWeight: '600' },
});
