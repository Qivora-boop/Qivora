import { useEffect, useState, useRef } from 'react';
import {
  View, Text, StyleSheet, Image, TouchableOpacity,
  Animated, ScrollView, Platform, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import {
  Download, Share2, Bookmark, BookmarkCheck, ArrowLeft, Sparkles, RefreshCw,
} from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { IMAGE_STYLES } from '@/lib/imageGenerator';
import GradientButton from '@/components/GradientButton';
import { colors, spacing, radius, typography } from '@/constants/theme';

type ImageData = {
  id: string;
  prompt: string;
  style: string;
  image_url: string;
  is_saved: boolean;
  created_at: string;
};

export default function ResultScreen() {
  const { imageId } = useLocalSearchParams<{ imageId: string }>();
  const { user } = useAuth();
  const [imageData, setImageData] = useState<ImageData | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const imageAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(40)).current;

  useEffect(() => {
    if (!imageId) return;
    fetchImage();
  }, [imageId]);

  async function fetchImage() {
    const { data } = await supabase
      .from('generated_images')
      .select('id, user_id, prompt, style, image_url, is_saved, created_at')
      .eq('id', imageId)
      .maybeSingle();
    setImageData(data as ImageData | null);
    setLoading(false);
    // Animate in
    Animated.parallel([
      Animated.timing(imageAnim, { toValue: 1, duration: 500, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 500, useNativeDriver: true }),
    ]).start();
  }

  async function toggleSave() {
    if (!imageData) return;
    setSaving(true);
    const newSaved = !imageData.is_saved;
    await supabase
      .from('generated_images')
      .update({ is_saved: newSaved })
      .eq('id', imageData.id);
    setImageData(prev => prev ? { ...prev, is_saved: newSaved } : prev);
    setSaving(false);
  }

  function handleShare() {
    if (Platform.OS === 'web') {
      if (imageData?.image_url) {
        navigator.clipboard?.writeText(imageData.image_url);
        Alert.alert('Copied!', 'Image URL copied to clipboard');
      }
    }
  }

  function handleDownload() {
    if (Platform.OS === 'web' && imageData?.image_url) {
      const link = document.createElement('a');
      link.href = imageData.image_url;
      link.download = `pixelmind-${imageData.id.slice(0, 8)}.jpg`;
      link.target = '_blank';
      link.click();
    }
  }

  const styleInfo = IMAGE_STYLES.find(s => s.id === imageData?.style);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <LinearGradient colors={[colors.background, '#0A0A1A']} style={StyleSheet.absoluteFillObject} />
        <View style={styles.loadingContent}>
          <Animated.View style={[styles.loadingPulse]}>
            <Sparkles color={colors.primary} size={40} />
          </Animated.View>
          <Text style={styles.loadingText}>Loading result...</Text>
        </View>
      </View>
    );
  }

  if (!imageData) {
    return (
      <View style={styles.loadingContainer}>
        <LinearGradient colors={[colors.background, '#0A0A1A']} style={StyleSheet.absoluteFillObject} />
        <Text style={styles.loadingText}>Image not found</Text>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <Text style={{ color: colors.primaryLight }}>Go back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <LinearGradient colors={[colors.background, '#0A0A1A']} style={styles.bg}>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Back button */}
        <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
          <ArrowLeft color={colors.text} size={20} />
          <Text style={styles.backText}>Back</Text>
        </TouchableOpacity>

        <Text style={styles.title}>Your Creation</Text>
        <Text style={styles.subtitle}>AI-generated masterpiece</Text>

        {/* Image */}
        <Animated.View style={[styles.imageContainer, { opacity: imageAnim }]}>
          <LinearGradient
            colors={[colors.primaryGlow, 'transparent']}
            style={styles.imageGlow}
          />
          <Image
            source={{ uri: imageData.image_url }}
            style={styles.image}
            resizeMode="cover"
          />
          {/* Style badge */}
          <View style={styles.styleBadge}>
            <Text style={styles.styleBadgeIcon}>{styleInfo?.icon ?? '✨'}</Text>
            <Text style={styles.styleBadgeText}>{styleInfo?.label ?? imageData.style}</Text>
          </View>
        </Animated.View>

        {/* Prompt */}
        <Animated.View style={[styles.promptCard, { opacity: imageAnim, transform: [{ translateY: slideAnim }] }]}>
          <Text style={styles.promptLabel}>Prompt</Text>
          <Text style={styles.promptText}>"{imageData.prompt}"</Text>
        </Animated.View>

        {/* Action buttons */}
        <Animated.View style={[styles.actions, { opacity: imageAnim, transform: [{ translateY: slideAnim }] }]}>
          <TouchableOpacity style={styles.actionBtn} onPress={handleDownload}>
            <LinearGradient colors={[colors.surfaceElevated, colors.surface]} style={styles.actionGradient}>
              <Download color={colors.text} size={22} />
              <Text style={styles.actionText}>Download</Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionBtn} onPress={handleShare}>
            <LinearGradient colors={[colors.surfaceElevated, colors.surface]} style={styles.actionGradient}>
              <Share2 color={colors.text} size={22} />
              <Text style={styles.actionText}>Share</Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity style={styles.actionBtn} onPress={toggleSave} disabled={saving}>
            <LinearGradient
              colors={imageData.is_saved ? [colors.primaryDark, colors.primary] : [colors.surfaceElevated, colors.surface]}
              style={styles.actionGradient}
            >
              {imageData.is_saved
                ? <BookmarkCheck color="#fff" size={22} />
                : <Bookmark color={colors.text} size={22} />
              }
              <Text style={[styles.actionText, imageData.is_saved && { color: '#fff' }]}>
                {imageData.is_saved ? 'Saved' : 'Save'}
              </Text>
            </LinearGradient>
          </TouchableOpacity>
        </Animated.View>

        {/* Bottom actions */}
        <Animated.View style={{ opacity: imageAnim, transform: [{ translateY: slideAnim }] }}>
          <GradientButton
            title="Generate Another"
            onPress={() => router.replace('/(tabs)')}
            style={{ marginBottom: spacing.md }}
          />
          <GradientButton
            title="View Gallery"
            onPress={() => router.push('/(tabs)/gallery')}
            variant="outline"
          />
        </Animated.View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1 },
  scroll: { padding: spacing.lg, paddingTop: 60, paddingBottom: 100 },
  loadingContainer: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  loadingContent: { alignItems: 'center', gap: spacing.md },
  loadingPulse: {
    width: 80, height: 80, borderRadius: 40,
    backgroundColor: 'rgba(147, 51, 234, 0.1)',
    alignItems: 'center', justifyContent: 'center',
  },
  loadingText: { ...typography.body, color: colors.textSecondary },
  backButton: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.xs,
    marginBottom: spacing.md, alignSelf: 'flex-start',
  },
  backText: { ...typography.body, color: colors.text },
  backBtn: { marginTop: spacing.md },
  title: { ...typography.h2, color: colors.text, marginBottom: 4 },
  subtitle: { ...typography.bodySmall, color: colors.textMuted, marginBottom: spacing.lg },
  imageContainer: {
    borderRadius: radius.xl,
    overflow: 'hidden',
    marginBottom: spacing.lg,
    position: 'relative',
    borderWidth: 1,
    borderColor: colors.border,
  },
  imageGlow: {
    position: 'absolute',
    top: -40,
    left: -40,
    right: -40,
    height: 200,
    zIndex: 1,
    borderRadius: radius.xl,
  },
  image: { width: '100%', aspectRatio: 1, borderRadius: radius.xl },
  styleBadge: {
    position: 'absolute',
    top: spacing.md,
    right: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(10, 10, 15, 0.8)',
    borderRadius: radius.full,
    paddingVertical: 5,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  styleBadgeIcon: { fontSize: 12 },
  styleBadgeText: { ...typography.caption, color: colors.textSecondary, fontWeight: '600' },
  promptCard: {
    backgroundColor: colors.surface,
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    marginBottom: spacing.lg,
  },
  promptLabel: { ...typography.label, color: colors.textMuted, textTransform: 'uppercase', marginBottom: 6 },
  promptText: { ...typography.body, color: colors.text, fontStyle: 'italic', lineHeight: 24 },
  actions: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.lg },
  actionBtn: { flex: 1, borderRadius: radius.lg, overflow: 'hidden' },
  actionGradient: {
    padding: spacing.md,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.lg,
  },
  actionText: { ...typography.caption, color: colors.textSecondary, fontWeight: '600' },
});
