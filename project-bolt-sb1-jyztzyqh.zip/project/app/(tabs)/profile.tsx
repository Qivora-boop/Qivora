import { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import {
  User, Crown, Zap, Image as ImageIcon, LogOut, ChevronRight, Settings, Bell,
} from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import GradientButton from '@/components/GradientButton';
import { colors, spacing, radius, typography } from '@/constants/theme';

export default function ProfileScreen() {
  const { profile, user, signOut } = useAuth();
  const [signingOut, setSigningOut] = useState(false);

  async function handleSignOut() {
    Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Sign Out', style: 'destructive',
        onPress: async () => {
          setSigningOut(true);
          await signOut();
          router.replace('/(auth)/login');
        },
      },
    ]);
  }

  const initials = (profile?.username ?? user?.email ?? 'U').slice(0, 2).toUpperCase();

  return (
    <LinearGradient colors={[colors.background, '#0A0A1A']} style={styles.bg}>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Avatar section */}
        <View style={styles.avatarSection}>
          <LinearGradient
            colors={[colors.primaryDark, colors.primary, colors.primaryLight]}
            style={styles.avatar}
          >
            <Text style={styles.avatarText}>{initials}</Text>
          </LinearGradient>
          <Text style={styles.username}>{profile?.username ?? 'Creator'}</Text>
          <Text style={styles.email}>{user?.email}</Text>
          {profile?.is_premium && (
            <View style={styles.premiumTag}>
              <Crown color={colors.warning} size={12} />
              <Text style={styles.premiumTagText}>PREMIUM</Text>
            </View>
          )}
        </View>

        {/* Stats row */}
        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <LinearGradient colors={['rgba(147,51,234,0.15)', 'transparent']} style={[StyleSheet.absoluteFillObject, { borderRadius: radius.lg }]} />
            <Zap color={colors.warning} size={20} fill={colors.warning} />
            <Text style={styles.statValue}>{profile?.credits ?? 0}</Text>
            <Text style={styles.statLabel}>Credits</Text>
          </View>
          <View style={styles.statCard}>
            <LinearGradient colors={['rgba(147,51,234,0.15)', 'transparent']} style={[StyleSheet.absoluteFillObject, { borderRadius: radius.lg }]} />
            <ImageIcon color={colors.primaryLight} size={20} />
            <Text style={styles.statValue}>∞</Text>
            <Text style={styles.statLabel}>Created</Text>
          </View>
          <View style={styles.statCard}>
            <LinearGradient colors={['rgba(147,51,234,0.15)', 'transparent']} style={[StyleSheet.absoluteFillObject, { borderRadius: radius.lg }]} />
            <Crown color={colors.warning} size={20} />
            <Text style={styles.statValue}>{profile?.is_premium ? 'Pro' : 'Free'}</Text>
            <Text style={styles.statLabel}>Plan</Text>
          </View>
        </View>

        {/* Menu items */}
        <View style={styles.menuSection}>
          <Text style={styles.menuSectionLabel}>Account</Text>
          {[
            {
              icon: Zap, label: 'Buy Credits', sub: `${profile?.credits ?? 0} remaining`,
              onPress: () => router.push('/(tabs)/credits'), color: colors.warning,
            },
            {
              icon: Crown, label: 'Premium Plan', sub: profile?.is_premium ? 'Active' : 'Upgrade for unlimited',
              onPress: () => router.push('/(tabs)/credits'), color: colors.primaryLight,
            },
            {
              icon: ImageIcon, label: 'My Gallery', sub: 'View your creations',
              onPress: () => router.push('/(tabs)/gallery'), color: colors.textSecondary,
            },
          ].map(({ icon: Icon, label, sub, onPress, color }) => (
            <TouchableOpacity key={label} style={styles.menuItem} onPress={onPress} activeOpacity={0.7}>
              <View style={[styles.menuIconWrap, { backgroundColor: `${color}18` }]}>
                <Icon color={color} size={18} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.menuLabel}>{label}</Text>
                <Text style={styles.menuSub}>{sub}</Text>
              </View>
              <ChevronRight color={colors.textMuted} size={18} />
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.menuSection}>
          <Text style={styles.menuSectionLabel}>Preferences</Text>
          {[
            { icon: Bell, label: 'Notifications', sub: 'Manage alerts' },
            { icon: Settings, label: 'Settings', sub: 'App preferences' },
          ].map(({ icon: Icon, label, sub }) => (
            <TouchableOpacity key={label} style={styles.menuItem} activeOpacity={0.7}>
              <View style={[styles.menuIconWrap, { backgroundColor: 'rgba(107,107,138,0.15)' }]}>
                <Icon color={colors.textMuted} size={18} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.menuLabel}>{label}</Text>
                <Text style={styles.menuSub}>{sub}</Text>
              </View>
              <ChevronRight color={colors.textMuted} size={18} />
            </TouchableOpacity>
          ))}
        </View>

        <GradientButton
          title={signingOut ? 'Signing out...' : 'Sign Out'}
          onPress={handleSignOut}
          variant="outline"
          loading={signingOut}
          style={{ marginTop: spacing.md }}
        />

        <Text style={styles.version}>PixelMind AI v1.0.0</Text>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1 },
  scroll: { padding: spacing.lg, paddingTop: 60, paddingBottom: 100 },
  avatarSection: { alignItems: 'center', marginBottom: spacing.xl },
  avatar: {
    width: 88, height: 88, borderRadius: 44,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: spacing.md,
    shadowColor: colors.primary, shadowOpacity: 0.5, shadowRadius: 20, elevation: 10,
  },
  avatarText: { fontSize: 32, fontWeight: '800', color: '#fff' },
  username: { ...typography.h2, color: colors.text, marginBottom: 4 },
  email: { ...typography.bodySmall, color: colors.textMuted, marginBottom: spacing.sm },
  premiumTag: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: 'rgba(245,158,11,0.12)',
    borderRadius: radius.full, borderWidth: 1, borderColor: 'rgba(245,158,11,0.3)',
    paddingVertical: 5, paddingHorizontal: 12,
  },
  premiumTagText: { fontSize: 10, color: colors.warning, fontWeight: '800', letterSpacing: 0.5 },
  statsRow: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.xl },
  statCard: {
    flex: 1, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border,
    padding: spacing.md, alignItems: 'center', gap: 4, overflow: 'hidden',
  },
  statValue: { ...typography.h3, color: colors.text },
  statLabel: { ...typography.caption, color: colors.textMuted },
  menuSection: { marginBottom: spacing.lg },
  menuSectionLabel: { ...typography.label, color: colors.textMuted, textTransform: 'uppercase', marginBottom: spacing.sm },
  menuItem: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.md,
    backgroundColor: colors.surface, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border,
    padding: spacing.md, marginBottom: spacing.sm,
  },
  menuIconWrap: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  menuLabel: { ...typography.body, color: colors.text, fontWeight: '600' },
  menuSub: { ...typography.caption, color: colors.textMuted, marginTop: 1 },
  version: { ...typography.caption, color: colors.textMuted, textAlign: 'center', marginTop: spacing.lg },
});
