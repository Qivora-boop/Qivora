import { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Zap, Crown, Check, Star, Shield, Infinity } from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import GradientButton from '@/components/GradientButton';
import { colors, spacing, radius, typography } from '@/constants/theme';

const CREDIT_PACKS = [
  { id: 'starter', name: 'Starter Pack', credits: 25, price: '$2.99', priceNum: 2.99, popular: false, color: [colors.surface, colors.surfaceElevated] as [string,string] },
  { id: 'creator', name: 'Creator Pack', credits: 75, price: '$6.99', priceNum: 6.99, popular: true, color: [colors.primaryDark, colors.primary] as [string,string] },
  { id: 'pro', name: 'Pro Pack', credits: 200, price: '$14.99', priceNum: 14.99, popular: false, color: [colors.surface, colors.surfaceElevated] as [string,string] },
];

const PREMIUM_FEATURES = [
  { icon: Infinity, text: 'Unlimited generations' },
  { icon: Zap, text: 'Priority processing' },
  { icon: Star, text: 'Exclusive styles & filters' },
  { icon: Shield, text: 'No watermarks' },
  { icon: Crown, text: 'Early access to new features' },
];

export default function CreditsScreen() {
  const { user, profile, refreshProfile } = useAuth();
  const [purchasing, setPurchasing] = useState<string | null>(null);

  async function handlePurchase(pack: typeof CREDIT_PACKS[0]) {
    if (!user || !profile) return;
    setPurchasing(pack.id);
    // Simulate payment processing
    await new Promise(r => setTimeout(r, 1500));

    try {
      await Promise.all([
        supabase.from('profiles').update({
          credits: profile.credits + pack.credits,
          updated_at: new Date().toISOString(),
        }).eq('id', user.id),
        supabase.from('credit_transactions').insert({
          user_id: user.id,
          amount: pack.credits,
          type: 'purchase',
          description: `Purchased ${pack.name}: +${pack.credits} credits`,
        }),
      ]);
      await refreshProfile();
      Alert.alert('Purchase Successful!', `${pack.credits} credits added to your account.`);
    } catch {
      Alert.alert('Error', 'Purchase failed. Please try again.');
    } finally {
      setPurchasing(null);
    }
  }

  async function handlePremium() {
    if (!user || !profile) return;
    setPurchasing('premium');
    await new Promise(r => setTimeout(r, 1500));
    try {
      await Promise.all([
        supabase.from('profiles').update({
          is_premium: true,
          credits: profile.credits + 100,
          updated_at: new Date().toISOString(),
        }).eq('id', user.id),
        supabase.from('credit_transactions').insert({
          user_id: user.id,
          amount: 100,
          type: 'purchase',
          description: 'Premium subscription activated: +100 credits',
        }),
      ]);
      await refreshProfile();
      Alert.alert('Welcome to Premium!', 'You now have unlimited access and 100 bonus credits.');
    } catch {
      Alert.alert('Error', 'Activation failed. Please try again.');
    } finally {
      setPurchasing(null);
    }
  }

  return (
    <LinearGradient colors={[colors.background, '#0A0A1A']} style={styles.bg}>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Credits & Premium</Text>
          <Text style={styles.subtitle}>Power up your creativity</Text>
        </View>

        {/* Credits balance card */}
        <LinearGradient
          colors={['rgba(124,58,237,0.25)', 'rgba(147,51,234,0.1)']}
          style={styles.balanceCard}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          <View style={styles.balanceTop}>
            <View>
              <Text style={styles.balanceLabel}>Your Balance</Text>
              <View style={styles.balanceRow}>
                <Zap color={colors.warning} size={28} fill={colors.warning} />
                <Text style={styles.balanceAmount}>{profile?.credits ?? 0}</Text>
                <Text style={styles.balanceUnit}>credits</Text>
              </View>
            </View>
            {profile?.is_premium && (
              <View style={styles.premiumBadge}>
                <Crown color={colors.warning} size={14} />
                <Text style={styles.premiumBadgeText}>PREMIUM</Text>
              </View>
            )}
          </View>
          <Text style={styles.balanceInfo}>Each image generation costs 1 credit</Text>
        </LinearGradient>

        {/* Premium offer */}
        {!profile?.is_premium && (
          <View style={styles.premiumCard}>
            <LinearGradient
              colors={['rgba(124,58,237,0.15)', 'rgba(147,51,234,0.05)']}
              style={[StyleSheet.absoluteFillObject, { borderRadius: radius.xl }]}
            />
            <View style={styles.premiumHeader}>
              <View style={styles.premiumIconContainer}>
                <LinearGradient colors={['#F59E0B', '#D97706']} style={styles.premiumIcon}>
                  <Crown color="#fff" size={22} />
                </LinearGradient>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.premiumTitle}>PixelMind Premium</Text>
                <Text style={styles.premiumPrice}>$9.99 / month</Text>
              </View>
            </View>

            <View style={styles.featureList}>
              {PREMIUM_FEATURES.map(({ icon: Icon, text }, i) => (
                <View key={i} style={styles.featureRow}>
                  <View style={styles.featureIconWrap}>
                    <Icon color={colors.primaryLight} size={16} />
                  </View>
                  <Text style={styles.featureText}>{text}</Text>
                </View>
              ))}
            </View>

            <GradientButton
              title={purchasing === 'premium' ? 'Activating...' : 'Get Premium — $9.99/mo'}
              onPress={handlePremium}
              loading={purchasing === 'premium'}
            />
          </View>
        )}

        {profile?.is_premium && (
          <View style={styles.premiumActiveCard}>
            <LinearGradient colors={['rgba(34,197,94,0.1)', 'transparent']} style={[StyleSheet.absoluteFillObject, { borderRadius: radius.xl }]} />
            <Crown color={colors.warning} size={28} />
            <View>
              <Text style={styles.premiumActiveTitle}>Premium Active</Text>
              <Text style={styles.premiumActiveText}>You have unlimited access to all features</Text>
            </View>
          </View>
        )}

        {/* Credit packs */}
        <Text style={styles.sectionTitle}>Buy Credits</Text>
        <Text style={styles.sectionSubtitle}>Top up anytime, no subscription needed</Text>

        <View style={styles.packs}>
          {CREDIT_PACKS.map(pack => (
            <TouchableOpacity
              key={pack.id}
              style={[styles.packCard, pack.popular && styles.packCardPopular]}
              onPress={() => handlePurchase(pack)}
              activeOpacity={0.8}
              disabled={purchasing !== null}
            >
              <LinearGradient colors={pack.color} style={[StyleSheet.absoluteFillObject, { borderRadius: radius.lg }]} />
              {pack.popular && (
                <View style={styles.popularBadge}>
                  <Text style={styles.popularBadgeText}>BEST VALUE</Text>
                </View>
              )}
              <Zap color={pack.popular ? '#fff' : colors.warning} size={24} fill={pack.popular ? '#fff' : colors.warning} />
              <Text style={[styles.packCredits, pack.popular && { color: '#fff' }]}>{pack.credits}</Text>
              <Text style={[styles.packUnit, pack.popular && { color: 'rgba(255,255,255,0.7)' }]}>credits</Text>
              <Text style={[styles.packName, pack.popular && { color: '#fff' }]}>{pack.name}</Text>
              <View style={[styles.packPriceBtn, pack.popular && styles.packPriceBtnPopular]}>
                {purchasing === pack.id ? (
                  <Text style={[styles.packPrice, pack.popular && { color: colors.primary }]}>...</Text>
                ) : (
                  <Text style={[styles.packPrice, pack.popular && { color: colors.primary }]}>{pack.price}</Text>
                )}
              </View>
            </TouchableOpacity>
          ))}
        </View>

        {/* Free credits tip */}
        <View style={styles.freeBox}>
          <Text style={styles.freeIcon}>🎁</Text>
          <View style={{ flex: 1 }}>
            <Text style={styles.freeTitle}>Earn free credits</Text>
            <Text style={styles.freeText}>Share your creations on social media and tag us for bonus credits!</Text>
          </View>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1 },
  scroll: { padding: spacing.lg, paddingTop: 60, paddingBottom: 100 },
  header: { marginBottom: spacing.lg },
  title: { ...typography.h2, color: colors.text },
  subtitle: { ...typography.bodySmall, color: colors.textMuted, marginTop: 2 },
  balanceCard: {
    borderRadius: radius.xl,
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: 'rgba(147,51,234,0.25)',
    marginBottom: spacing.lg,
  },
  balanceTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: spacing.xs },
  balanceLabel: { ...typography.label, color: colors.textMuted, textTransform: 'uppercase', marginBottom: 4 },
  balanceRow: { flexDirection: 'row', alignItems: 'flex-end', gap: spacing.xs },
  balanceAmount: { fontSize: 40, fontWeight: '800', color: colors.text, lineHeight: 46 },
  balanceUnit: { ...typography.body, color: colors.textMuted, paddingBottom: 6 },
  balanceInfo: { ...typography.caption, color: colors.textMuted },
  premiumBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: 'rgba(245,158,11,0.15)',
    borderRadius: radius.full, borderWidth: 1, borderColor: 'rgba(245,158,11,0.3)',
    paddingVertical: 5, paddingHorizontal: 10,
  },
  premiumBadgeText: { fontSize: 10, color: colors.warning, fontWeight: '800', letterSpacing: 0.5 },
  premiumCard: {
    borderRadius: radius.xl,
    borderWidth: 1,
    borderColor: 'rgba(147,51,234,0.25)',
    padding: spacing.lg,
    marginBottom: spacing.lg,
    overflow: 'hidden',
  },
  premiumHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginBottom: spacing.lg },
  premiumIconContainer: { borderRadius: radius.md, overflow: 'hidden' },
  premiumIcon: { width: 48, height: 48, borderRadius: radius.md, alignItems: 'center', justifyContent: 'center' },
  premiumTitle: { ...typography.h3, color: colors.text },
  premiumPrice: { ...typography.bodySmall, color: colors.textSecondary, marginTop: 2 },
  featureList: { gap: spacing.sm, marginBottom: spacing.lg },
  featureRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  featureIconWrap: {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: 'rgba(147,51,234,0.15)',
    alignItems: 'center', justifyContent: 'center',
  },
  featureText: { ...typography.bodySmall, color: colors.text },
  premiumActiveCard: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.md,
    borderRadius: radius.xl, borderWidth: 1, borderColor: 'rgba(34,197,94,0.2)',
    padding: spacing.lg, marginBottom: spacing.lg, overflow: 'hidden',
  },
  premiumActiveTitle: { ...typography.h3, color: colors.success },
  premiumActiveText: { ...typography.bodySmall, color: colors.textMuted, marginTop: 2 },
  sectionTitle: { ...typography.h3, color: colors.text, marginBottom: 4 },
  sectionSubtitle: { ...typography.bodySmall, color: colors.textMuted, marginBottom: spacing.md },
  packs: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.lg },
  packCard: {
    flex: 1, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border,
    padding: spacing.md, alignItems: 'center', gap: 4, overflow: 'hidden',
    position: 'relative',
  },
  packCardPopular: { borderColor: colors.primary },
  popularBadge: {
    position: 'absolute', top: 0, right: 0,
    backgroundColor: colors.primaryLight,
    borderBottomLeftRadius: radius.md,
    paddingVertical: 3, paddingHorizontal: 7,
  },
  popularBadgeText: { fontSize: 8, color: '#fff', fontWeight: '800', letterSpacing: 0.5 },
  packCredits: { fontSize: 28, fontWeight: '800', color: colors.text },
  packUnit: { ...typography.caption, color: colors.textMuted },
  packName: { ...typography.caption, color: colors.textMuted, textAlign: 'center' },
  packPriceBtn: {
    backgroundColor: colors.surfaceElevated,
    borderRadius: radius.md, borderWidth: 1, borderColor: colors.border,
    paddingVertical: 7, paddingHorizontal: 12, marginTop: 4,
    width: '100%', alignItems: 'center',
  },
  packPriceBtnPopular: { backgroundColor: '#fff' },
  packPrice: { fontWeight: '700', color: colors.text, fontSize: 13 },
  freeBox: {
    flexDirection: 'row', alignItems: 'flex-start', gap: spacing.md,
    backgroundColor: colors.surface, borderRadius: radius.lg,
    borderWidth: 1, borderColor: colors.border, padding: spacing.md,
  },
  freeIcon: { fontSize: 28 },
  freeTitle: { ...typography.body, color: colors.text, fontWeight: '600', marginBottom: 4 },
  freeText: { ...typography.bodySmall, color: colors.textMuted, lineHeight: 20 },
});
