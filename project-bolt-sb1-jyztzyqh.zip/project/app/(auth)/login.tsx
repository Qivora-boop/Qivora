import { useState } from 'react';
import {
  View, Text, TextInput, StyleSheet, TouchableOpacity,
  KeyboardAvoidingView, Platform, ScrollView, Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Link, router } from 'expo-router';
import { Eye, EyeOff, Sparkles } from 'lucide-react-native';
import { useAuth } from '@/context/AuthContext';
import GradientButton from '@/components/GradientButton';
import { colors, spacing, radius, typography } from '@/constants/theme';

export default function LoginScreen() {
  const { signIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleLogin() {
    if (!email.trim() || !password.trim()) {
      setError('Please fill in all fields');
      return;
    }
    setError(null);
    setLoading(true);
    const { error: err } = await signIn(email.trim(), password);
    setLoading(false);
    if (err) {
      setError(err);
    } else {
      router.replace('/(tabs)');
    }
  }

  return (
    <LinearGradient colors={[colors.background, '#0F0A1A']} style={styles.bg}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
          <View style={styles.header}>
            <View style={styles.logoContainer}>
              <LinearGradient
                colors={[colors.primaryDark, colors.primary]}
                style={styles.logoGradient}
              >
                <Sparkles color="#fff" size={32} />
              </LinearGradient>
            </View>
            <Text style={styles.appName}>PixelMind AI</Text>
            <Text style={styles.tagline}>Transform ideas into art</Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardTitle}>Welcome back</Text>
            <Text style={styles.cardSubtitle}>Sign in to continue creating</Text>

            {error && (
              <View style={styles.errorBox}>
                <Text style={styles.errorText}>{error}</Text>
              </View>
            )}

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Email</Text>
              <TextInput
                style={styles.input}
                placeholder="you@example.com"
                placeholderTextColor={colors.textMuted}
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                autoComplete="email"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Password</Text>
              <View style={styles.passwordRow}>
                <TextInput
                  style={[styles.input, { flex: 1, marginBottom: 0 }]}
                  placeholder="Your password"
                  placeholderTextColor={colors.textMuted}
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPassword}
                  autoComplete="password"
                />
                <TouchableOpacity
                  style={styles.eyeBtn}
                  onPress={() => setShowPassword(v => !v)}
                >
                  {showPassword
                    ? <EyeOff color={colors.textMuted} size={20} />
                    : <Eye color={colors.textMuted} size={20} />
                  }
                </TouchableOpacity>
              </View>
            </View>

            <GradientButton
              title="Sign In"
              onPress={handleLogin}
              loading={loading}
              style={{ marginTop: spacing.sm }}
            />

            <View style={styles.divider}>
              <View style={styles.dividerLine} />
              <Text style={styles.dividerText}>or</Text>
              <View style={styles.dividerLine} />
            </View>

            <View style={styles.signupRow}>
              <Text style={styles.signupText}>Don't have an account? </Text>
              <Link href="/(auth)/signup" asChild>
                <TouchableOpacity>
                  <Text style={styles.signupLink}>Create one</Text>
                </TouchableOpacity>
              </Link>
            </View>
          </View>

          <View style={styles.previewImages}>
            <Text style={styles.previewTitle}>Generate stunning AI art</Text>
            <View style={styles.imageRow}>
              {[
                'https://images.pexels.com/photos/3109807/pexels-photo-3109807.jpeg?auto=compress&cs=tinysrgb&w=200',
                'https://images.pexels.com/photos/1366919/pexels-photo-1366919.jpeg?auto=compress&cs=tinysrgb&w=200',
                'https://images.pexels.com/photos/2387418/pexels-photo-2387418.jpeg?auto=compress&cs=tinysrgb&w=200',
              ].map((uri, i) => (
                <Image key={i} source={{ uri }} style={styles.previewImage} />
              ))}
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  bg: { flex: 1 },
  scroll: { flexGrow: 1, padding: spacing.lg, paddingTop: 60 },
  header: { alignItems: 'center', marginBottom: spacing.xl },
  logoContainer: { marginBottom: spacing.md },
  logoGradient: {
    width: 72, height: 72, borderRadius: 20,
    alignItems: 'center', justifyContent: 'center',
    shadowColor: colors.primary, shadowOpacity: 0.6, shadowRadius: 20, elevation: 10,
  },
  appName: { ...typography.h1, color: colors.text, marginBottom: 4 },
  tagline: { ...typography.body, color: colors.textSecondary },
  card: {
    backgroundColor: colors.surface,
    borderRadius: radius.xl,
    padding: spacing.lg,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: spacing.xl,
  },
  cardTitle: { ...typography.h2, color: colors.text, marginBottom: 4 },
  cardSubtitle: { ...typography.bodySmall, color: colors.textMuted, marginBottom: spacing.lg },
  errorBox: {
    backgroundColor: 'rgba(239,68,68,0.12)',
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  errorText: { color: colors.error, ...typography.bodySmall },
  inputGroup: { marginBottom: spacing.md },
  label: { ...typography.label, color: colors.textSecondary, marginBottom: 6, textTransform: 'uppercase' },
  input: {
    backgroundColor: colors.surfaceElevated,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    color: colors.text,
    paddingVertical: 14,
    paddingHorizontal: spacing.md,
    ...typography.body,
  },
  passwordRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  eyeBtn: {
    backgroundColor: colors.surfaceElevated,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    padding: 14,
  },
  divider: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginVertical: spacing.md },
  dividerLine: { flex: 1, height: 1, backgroundColor: colors.border },
  dividerText: { ...typography.caption, color: colors.textMuted },
  signupRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center' },
  signupText: { ...typography.bodySmall, color: colors.textMuted },
  signupLink: { ...typography.bodySmall, color: colors.primaryLight, fontWeight: '700' },
  previewImages: { alignItems: 'center' },
  previewTitle: { ...typography.bodySmall, color: colors.textMuted, marginBottom: spacing.sm },
  imageRow: { flexDirection: 'row', gap: spacing.sm },
  previewImage: { width: 88, height: 88, borderRadius: radius.md },
});
