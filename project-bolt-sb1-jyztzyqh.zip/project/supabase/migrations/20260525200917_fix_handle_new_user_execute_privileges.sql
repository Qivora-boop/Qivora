/*
  # Fix handle_new_user Execute Privileges

  ## Summary
  Properly revokes EXECUTE privileges from all roles that shouldn't have access.

  ## Problem
  The previous migration revoked from `anon` and `authenticated` directly, but these roles
  inherit privileges from `PUBLIC`. When PUBLIC has execute privileges, revoking from
  specific roles doesn't fully remove access.

  ## Solution
  1. Revoke from PUBLIC first (this removes default execute access)
  2. Then revoke from anon and authenticated explicitly
  3. Only postgres (superuser) should be able to execute

  ## Verification
  After this migration, only postgres should appear in the function privileges.
*/

-- Revoke from PUBLIC first (this is the key step that was missing)
REVOKE ALL ON FUNCTION public.handle_new_user() FROM PUBLIC;

-- Revoke from specific roles
REVOKE ALL ON FUNCTION public.handle_new_user() FROM anon;
REVOKE ALL ON FUNCTION public.handle_new_user() FROM authenticated;

-- Grant only to postgres
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO postgres;
