/*
  # Fix handle_new_user Security Issues

  ## Summary
  Addresses three security vulnerabilities in the handle_new_user function:
  1. Mutable search_path - function could be exploited via search_path manipulation
  2. Public execution - anon role could invoke the SECURITY DEFINER function
  3. Authenticated execution - authenticated role could invoke the function

  ## Changes
  - Set `search_path` to an empty string, forcing fully qualified table references
  - Revoke EXECUTE privilege from anon and authenticated roles
  - Grant EXECUTE only to postgres (superuser) which is the role that runs triggers
  - The trigger on auth.users runs with superuser privileges, so the function will still work

  ## Security Notes
  1. The function is kept as SECURITY DEFINER because it needs elevated privileges to insert into public.profiles
  2. By revoking execute from anon/authenticated, users cannot call this function directly via the REST API
  3. The trigger on auth.users will still fire because triggers execute with the privilege of the table owner (postgres)
*/

-- Drop the existing function and recreate it with proper security
DROP FUNCTION IF EXISTS public.handle_new_user() CASCADE;

-- Recreate with fixed search_path and explicit schema qualifications
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = ''
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO public.profiles (id, username, credits, is_premium)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)),
    10,
    false
  );
  RETURN NEW;
END;
$$;

-- Revoke execute privileges from anon and authenticated
REVOKE ALL ON FUNCTION public.handle_new_user() FROM anon;
REVOKE ALL ON FUNCTION public.handle_new_user() FROM authenticated;

-- Ensure only postgres can execute (triggers run as table owner)
GRANT EXECUTE ON FUNCTION public.handle_new_user() TO postgres;

-- Re-add the trigger (was dropped with CASCADE)
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
